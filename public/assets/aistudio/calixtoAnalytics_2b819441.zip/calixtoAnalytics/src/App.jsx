import AnalyticsView from "./calixtoAnalytics/AnalyticsView";

export default function App() {
  return <AnalyticsView />;
}
