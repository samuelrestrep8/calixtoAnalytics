# CALLiSTO Analytics — Módulo de Analítica y Predicción con IA

Módulo independiente de analítica predictiva y planeación inteligente de inventario para **CALLiSTO**. Este módulo calcula sugerencias óptimas de reabastecimiento, proyecciones de demanda a 30 días, clasificación ABC (por valor y volumen) y análisis de recurrencia de clientes mediante un motor de Machine Learning (Random Forest) ejecutado directamente en el cliente.

---

## 🚀 Características Principales

1. **Motor de IA Predictivo (Client-Side)**:
   - Réplica optimizada en TypeScript de `RandomForestRegressor` ejecutándose en menos de 100 ms en el navegador.
   - Proyecciones de demanda diaria y agregada a 30 días basadas en el historial de transacciones.
2. **Conexión Directa al Backend**:
   - Conectado a la API en producción en Railway: `https://callistoserver.up.railway.app`
   - Consulta el catálogo de productos, existencias y precios con soporte CORS nativo.
3. **Reportes y Exportación**:
   - Descarga de órdenes de compra sugeridas en formato PDF con `jspdf` y `jspdf-autotable`.
   - Filtros por megacategoría, categoría, tipo de documento (ventas efectivas vs. netas) y proveedor.
4. **Modo Claro / Oscuro**:
   - Interfaz construida con Tailwind CSS y ApexCharts responsiva y estilizada.

---

## 🛠️ Tecnologías Utilizadas

- **Framework**: [React 18](https://react.dev/) + [Vite](https://vitejs.dev/)
- **Estilos**: [Tailwind CSS](https://tailwindcss.com/)
- **Gráficos**: [ApexCharts](https://apexcharts.com/) + `react-apexcharts`
- **Generación de PDF**: `jspdf` + `jspdf-autotable`
- **Peticiones HTTP**: `axios`

---

## 📁 Estructura del Proyecto

```text
calixto-analytics/
├── index.html
├── package.json
├── vite.config.js
├── tailwind.config.js
├── postcss.config.js
├── tsconfig.json
├── src/
│   ├── main.jsx
│   ├── App.jsx
│   ├── index.css
│   └── calixtoAnalytics/
│       ├── AnalyticsView.jsx        # Vista principal del módulo
│       ├── analytics.css            # Estilos personalizados de modo claro
│       ├── data/
│       │   └── zanngo-history.json  # Histórico transaccional (~600 KB)
│       └── engine/
│           ├── forecast.ts          # Algoritmo Random Forest Regressor
│           └── inventory-engine.ts  # Motor de cálculo de inventario y compras
└── dist/                            # Build de producción listo para desplegar
```

---

## 💻 Ejecución Local

1. Instalar dependencias:
   ```bash
   npm install
   ```
2. Iniciar servidor de desarrollo:
   ```bash
   npm run dev
   ```
3. Construir para producción:
   ```bash
   npm run build
   ```

---

## 🌐 Despliegue en Vercel

1. Sube este repositorio a **GitHub**.
2. Ingresa a [Vercel](https://vercel.com) e importa el repositorio.
3. Vercel detectará automáticamente que es un proyecto **Vite**:
   - **Framework Preset**: `Vite`
   - **Build Command**: `npm run build`
   - **Output Directory**: `dist`
4. Haz clic en **Deploy**. ¡Listo!
